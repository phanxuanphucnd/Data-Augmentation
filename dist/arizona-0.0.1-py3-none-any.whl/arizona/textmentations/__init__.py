# -*- coding: utf-8 -*-
# Copyright (c) Phuc Phan

from arizona.textmentations.augmentation import TextAugmentation